Snippet_Rest_JAVA-----------------
Url     : http://codes-sources.commentcamarche.net/source/100793-snippet-rest-javaAuteur  : gnaouidevDate    : 30/10/2014
Licence :
=========

Ce document intitul� � Snippet_Rest_JAVA � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

REST (REpresentational State Transfer) est un style d'architecture pour les syst
�mes hyperm�dia distribu�s, cr�� par Roy Fielding en 2000
<br />
<br />il perm
et � deux programmes poss�dant des langages de programmation diff�rents et s'exe
cutant sur des platformes diff�rents de se communiquer
<br />
<br />
