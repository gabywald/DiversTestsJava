package rest.x.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name="x")

// la class X est le mod�le de donn�e adopt� 
public class X {
	
	private int x1 ; 
	private String x2 ;
	private double x3 ;
	
	//constructeur par defaut
	public X() {
		
	}
	
	//constructeur de copie
	public X(int x1, String x2, double x3) {
		
		this.x1 = x1;
		this.x2 = x2;
		this.x3 = x3;
	}
	
	//constructeur de recopie
public X(X x) {
		
		this.x1 = x.x1;
		this.x2 = x.x2;
		this.x3 = x.x3;
	}
	
// les Getters et les Setters des attributs de la class x	
// pour les xmlelement c'est tous simplement pour sp�cifier les nom des balises transf�r�es vers le client 
// par exemple pour le premier attribut sa valeur va �tre plac� entre la balise <x1>et</x1>
// si on change required=true � name=datax1 la valeur de l'attribut x1 va �tre plac� entre la balise <datax1> et </datax1>

@XmlElement(required=true)
	public int getX1() {
		return x1;
	}
	public void setX1(int x1) {
		this.x1 = x1;
	}
	
@XmlElement(required=true)
	public String getX2() {
		return x2;
	}
	public void setX2(String x2) {
		this.x2 = x2;
	}

@XmlElement(required=true)
	public double getX3() {
		return x3;
	}
	public void setX3(double x3) {
		this.x3 = x3;
	}
	
	//methode affichant l'objet x en detail
public String AfficheX() {
		
		return "X  x1="+x1+" , x2="+x2+" , x3="+x3 ;
	}

}
