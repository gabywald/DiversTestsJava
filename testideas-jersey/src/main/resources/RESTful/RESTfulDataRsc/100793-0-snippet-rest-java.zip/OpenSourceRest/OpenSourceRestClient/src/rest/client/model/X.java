package rest.client.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name="x")


// la class x et la meme disponible chez le serveur , on peut ne pas l'utilis� mais dans notre cas elle est n�cessaire
public class X {
	
	private int x1 ; 
	private String x2 ;
	private double x3 ;
	
	
	public X() {
		
	}
	
	public X(int x1, String x2, double x3) {
		
		this.x1 = x1;
		this.x2 = x2;
		this.x3 = x3;
	}
	
public X(X x) {
		
		this.x1 = x.x1;
		this.x2 = x.x2;
		this.x3 = x.x3;
	}
	
	
@XmlElement(required=true)
	public int getX1() {
		return x1;
	}
	public void setX1(int x1) {
		this.x1 = x1;
	}
	
@XmlElement(required=true)
	public String getX2() {
		return x2;
	}
	public void setX2(String x2) {
		this.x2 = x2;
	}

@XmlElement(required=true)
	public double getX3() {
		return x3;
	}
	public void setX3(double x3) {
		this.x3 = x3;
	}
	
	
	public void AfficheX() {
		
		System.out.println("X  x1="+x1+" , x2="+x2+" , x3="+x3);
	}
	

}
