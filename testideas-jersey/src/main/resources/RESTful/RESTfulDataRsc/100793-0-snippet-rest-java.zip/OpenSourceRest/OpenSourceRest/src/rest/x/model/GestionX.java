package rest.x.model;

import java.util.ArrayList;

// class permettant la gestion de x(supp,crea,modif,affich) les 4 op�rations fondamentale d'une gestion x
public class GestionX {
	
	
	//Base de donn�e sous forme ArrayList
	static ArrayList<X> gx = new ArrayList<X>() ;
	
	
	//constructeur qui initie la base de donn�e
	public GestionX() {
		
		gx.add(new X(1,"val1",10)) ;
		gx.add(new X(2,"val2",20)) ;
		gx.add(new X(3,"val3",30)) ;
		
		
	}
	
	//methode retournant tous les x de notre base
	public ArrayList<X>  GetAllX() {
		
		return gx ;
		
	}
	
	//methode ajoutant un x
	public void AddX(X nx) {
		
		gx.add(nx) ;
		
	}
	
	//methode retournant un x a partir de son x1
	public X GetXByX1(int x1 ){
		
		X tmp = null ;
		
		for(X x:gx){
			
			if(x.getX1()==x1) { tmp=x ;   }
			
		}
		
		return tmp ;
		
	}
	
	//methode permet la suppression d'un x de la liste
	public void DeleteX(X dx){

		gx.remove(dx) ;
		
	}
	
	// methode permet de cr�er un x et l'ajouter a la liste
	public void Create(X cx) {
		
		gx.add(cx) ;
		
	}
	
	// methode testant l'existance d'un x avec son x1
	public boolean ExistTest(int x1){
		
		boolean rep=false ;
		
		for(X x:gx){
			
			if(x.getX1()==x1) { rep=true ;   }
			
		}
		
		return rep ;
		
	}
}
