package rest.x.service;

import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import rest.x.model.GestionX;
import rest.x.model.X;


// la class serviceX traite les requ�tes parvenant du client et repondant � son besoin

// ce path est tr�s important puisqu'il pr�cise la class contenant les traitement des services 
@Path("/x")
public class ServiceX {

	
	// gx est un objet static qui sera instanci� qu'une seul fois lors de l'execution , il contient l'arraylist de x et poss�de les m�thodes de gestion de x 
	static GestionX gx = new GestionX() ;
	
	
	
	// @GET �a veut dire que la demande va parvenir depuis un get (soit par l'url d'un navigateur soit on un programme client utilisant la methode get et ce client sera execute en tant qu'une application )
	//le @Path /getallx retournant la liste sous la forme d'un xml
	@GET
	@Path("/getallx")
	@Produces(MediaType.APPLICATION_XML)
	@Consumes(MediaType.APPLICATION_XML)
	
	public ArrayList<X> GetAllX_xml() {
		
		return gx.GetAllX() ;
	
	}
	
	
	
	//le @Path /getallxc retournant la liste sous la forme d'un xml
	@GET
	@Path("/getallxc")
	@Produces(MediaType.APPLICATION_XML)
	@Consumes(MediaType.TEXT_HTML)
	
	public String GetAllX_html() {
		
		String ch="" ;
		
		for(X x:gx.GetAllX()) {
			
			ch+=x.AfficheX()+"\n" ;
			
		}
		
		return ch ;
	
	}
	
	
	
	//service permettant de retourner un x par son id
	@GET
	@Path("/getx/{x1}")
	@Produces(MediaType.APPLICATION_XML)
	@Consumes(MediaType.APPLICATION_XML)
	
	public X GetXByX1(@PathParam("x1") int x1) {
		
		return gx.GetXByX1(x1) ;
	
	}
	
	
	
	// service permettant de creer un x depuis une demande post d'un client (programme-application et non une demmande par l'url d'un navigateur)
	// on peut utilis� l'annotation GET pour cr�er un x , ou la demande depuis l client sera un get , et le service aura le path /createx/{newx1}/{newx2}/{newx3} 
	@POST
	@Path("/createx")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	
	public void CreateX(X x) {
	
		gx.Create(x);
	
	}
	
	
	
	// service permettant de modifier un x depuis une demande put d'un client (programme-application et non une demmande par l'url d'un navigateur)
	@PUT
	@Path("/updatex/{x1u}/{x2u}/{x3u}")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.TEXT_PLAIN)
	
	public String UpdateX(@PathParam("x1u") int x1u,@PathParam("x2u") String x2u,@PathParam("x3u") double x3u) {
		
		boolean rep = gx.ExistTest(x1u) ;
		String ch="x not existe" ;
		
		
		if(rep) {  
			
			gx.GetXByX1(x1u).setX2(x2u);  
			gx.GetXByX1(x1u).setX3(x3u);   
			ch="x updated with succes" ;     }

		return ch ;
		
	}
	
	
	// service permettant de supprimer un x depuis une demande delete d'un client (programme-application et non une demmande par l'url d'un navigateur)
	@DELETE
	@Path("/deletex/{x1d}")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.TEXT_PLAIN)

	public String  DeleteX(@PathParam("x1d") int x1d)  {
		
		String ch="x not existe" ;
		
		if(gx.ExistTest(x1d)) {  
			
			gx.DeleteX(gx.GetXByX1(x1d)); 
			ch= " x deleted with succes" ; }
		
		return ch ;
	
		
	}



}



