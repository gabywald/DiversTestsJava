package rest.client;

import rest.client.model.X;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;



// class menuClient contenant le main du client cette class poss�dant des m�thodes permettant de demander un service au serveur wevService
public class MenuClient {

	ClientConfig config = new DefaultClientConfig();
    
    Client client = Client.create(config);
    
    WebResource service ;
    
    ClientResponse resp ;
	
	
	
    
    
    
	public static void main(String[] args) {


		MenuClient mc = new MenuClient() ; 
		
	//	mc.ClientCreateX();
	//	mc.ClientUpdateX(5,"val44",4440);
	//	mc.ClientdeleteX(4);
		mc.ClientGetAll();
	}
	
	
	
	//methode cr�ant un x par l'option post
	public void ClientCreateX() {
		
		
		try {
			service = client.resource("http://localhost:8080/OpenSourceRest/x/createx");
			X x = new X(4,"val4",40);
			resp = service.type("application/xml").post(ClientResponse.class,x) ;
			System.out.println("create x with succes ");
		
			}catch(Exception e ) { System.out.println("error create x ."+e.getMessage());   }
		
		
	}
	
	
	//methode modifiant un x on connaissant son x1 par l'option put , dans le cas ou ce x n'existe pas dans notre base un message de non existance s'affiche
	public void ClientUpdateX(int x1u , String newx2 , double newx3) {
		
		
		try {
			service = client.resource("http://localhost:8080/OpenSourceRest/x/updatex/"+x1u+"/"+newx2+"/"+newx3);
			
			resp = service.type("application/xml").put(ClientResponse.class) ;
			String output = resp.getEntity(String.class) ;
			System.out.println(output);
		
			}catch(Exception e ) { System.out.println("error update x ."+e.getMessage());   }
		
		
	}
	
	//methode supprimant un x on connaissant son x1 par l'option delete , dans le cas ou ce x n'existe pas dans notre base un message de non existance s'affiche

	public void ClientdeleteX(int x1d) {
		
		
		try {
			service = client.resource("http://localhost:8080/OpenSourceRest/x/deletex/"+x1d);
			resp = service.type("application/xml").delete(ClientResponse.class) ;
			String output = resp.getEntity(String.class) ;
			System.out.println(output);
		
			}catch(Exception e ) { System.out.println("error delete x ."+e.getMessage());   }
		
		
	}
	
	//methode affichant tous les x de notre base par l'option get 

	
	public void ClientGetAll() {
		
		try {
			service = client.resource("http://localhost:8080/OpenSourceRest/x/getallxc");
			resp = service.type("text/html").get(ClientResponse.class) ;
			String output = resp.getEntity(String.class) ;
			System.out.println(output);
		
			}catch(Exception e ) { System.out.println("error get all x ."+e.getMessage());   }
		
		
	}
	
}
